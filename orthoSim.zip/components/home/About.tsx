import React from "react";

const About = () => {
  return (
    <div id="about">
      <h2>What do we offer</h2>
      <p>
        Our project is a cutting-edge Virtual Reality (VR) surgery simulation
        designed to train medical students and surgical residents in
        Intramedullary Nailing of the Tibia. The system combines immersive VR
        technology with real-time feedback to provide a hands-on, realistic
        surgical experience.
      </p>
      <h2>Why It Matters</h2>
      <p>
        Traditional surgical training is often limited by cost, availability of
        cadavers, and patient safety concerns. Our simulation offers a safe,
        repeatable, and engaging environment for trainees to build competence
        and confidence before entering the operating room.
      </p>
      <h2>Who It&apos;s For</h2>
      <p>
        This project is aimed at medical schools, surgical training programs,
        and hospitals seeking innovative ways to enhance surgical education. It
        also supports surgeon trainees by providing progress tracking, mentor
        feedback, and integrated learning modules.
      </p>
      <h2>Our Vision</h2>
      <p>
        We believe immersive technology has the power to revolutionize medical
        training. Our goal is to build a platform that not only bridges the gap
        between theory and practice but also personalizes learning through
        data-driven insights and mentor interaction.
      </p>
    </div>
  );
};

export default About;
