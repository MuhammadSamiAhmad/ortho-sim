import {
  Brain,
  Gamepad2,
  BarChart2,
  Users,
  MessageSquare,
  Headset,
  Gauge,
  ClipboardCheck,
} from "lucide-react";

const features = [
  {
    icon: <Headset className="h-10 w-10 text-primary" />,
    title: "Immersive VR Experience",
    description:
      "Train in a realistic virtual operating room environment with accurate anatomical models and surgical instruments.",
  },
  {
    icon: <Brain className="h-10 w-10 text-primary" />,
    title: "AI-Powered Assistance",
    description:
      "Receive real-time guidance and feedback from our AI assistant specialized in orthopedic surgical techniques.",
  },
  {
    icon: <BarChart2 className="h-10 w-10 text-primary" />,
    title: "Performance Analytics",
    description:
      "Track your progress with detailed metrics on surgical precision, efficiency, and decision-making skills.",
  },
  {
    icon: <Users className="h-10 w-10 text-primary" />,
    title: "Mentor Feedback",
    description:
      "Experienced surgeons can provide personalized feedback and guidance on your simulation performance.",
  },
  {
    icon: <Gamepad2 className="h-10 w-10 text-primary" />,
    title: "Progressive Learning",
    description:
      "Start with basic procedures and advance to complex scenarios as your skills and confidence improve.",
  },
  {
    icon: <MessageSquare className="h-10 w-10 text-primary" />,
    title: "Community Support",
    description:
      "Connect with peers and mentors to discuss techniques, share experiences, and solve challenges.",
  },
  {
    icon: <Gauge className="h-10 w-10 text-primary" />,
    title: "Real-time Assessment",
    description:
      "Get immediate feedback on your performance with detailed scoring and improvement suggestions.",
  },
  {
    icon: <ClipboardCheck className="h-10 w-10 text-primary" />,
    title: "Comprehensive Curriculum",
    description:
      "Access a structured learning path with educational content, quizzes, and increasingly challenging simulations.",
  },
];

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 bg-muted/50">
      <div className="container px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Advanced Features for Surgical Training
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
            OrthoSim combines cutting-edge VR technology with educational
            expertise to provide the most effective surgical training
            experience.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <div
              key={index}
              className="flex flex-col items-center text-center p-6 bg-background rounded-lg border shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="p-3 rounded-full bg-primary/10 mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
