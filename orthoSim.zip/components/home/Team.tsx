import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Github, Linkedin, Twitter } from "lucide-react";
import Image from "next/image";

const teamMembers = [
  {
    name: "Dr. Sarah Johnson",
    role: "Founder & Chief Medical Officer",
    bio: "Orthopedic surgeon with 15+ years of experience specializing in trauma surgery and medical education.",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    name: "Michael Chen",
    role: "Chief Technology Officer",
    bio: "VR specialist with a background in medical simulation technology and computer science.",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    name: "Dr. James Wilson",
    role: "Lead Surgical Educator",
    bio: "Fellowship-trained orthopedic surgeon focused on developing evidence-based surgical training methods.",
    image: "/placeholder.svg?height=300&width=300",
  },
  {
    name: "Emily Rodriguez",
    role: "Head of User Experience",
    bio: "Human-computer interaction expert specializing in medical training applications and interfaces.",
    image: "/placeholder.svg?height=300&width=300",
  },
];

export function TeamSection() {
  return (
    <section id="team" className="py-20">
      <div className="container px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            Meet Our Team
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-3xl mx-auto">
            Our multidisciplinary team combines expertise in orthopedic surgery,
            medical education, and virtual reality technology.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {teamMembers.map((member, index) => (
            <Card key={index} className="overflow-hidden">
              <div className="aspect-square w-full overflow-hidden">
                <Image
                  src={member.image || "/placeholder.svg"}
                  alt={member.name}
                  layout="fill"
                  className="h-full w-full object-cover transition-transform hover:scale-105"
                />
              </div>
              <CardHeader className="p-4">
                <CardTitle className="text-xl">{member.name}</CardTitle>
                <CardDescription>{member.role}</CardDescription>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <p className="text-sm text-muted-foreground">{member.bio}</p>
              </CardContent>
              <CardFooter className="p-4 flex justify-center gap-4">
                <Button variant="ghost" size="icon" aria-label="Twitter">
                  <Twitter className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" aria-label="LinkedIn">
                  <Linkedin className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon" aria-label="GitHub">
                  <Github className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
