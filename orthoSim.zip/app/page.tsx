import { LandingNavbar } from "@/components/home/Navbar";
import { HeroSection } from "@/components/home/Hero";
import { FeaturesSection } from "@/components/home/Features";
import { TeamSection } from "@/components/home/Team";
import { FooterSection } from "@/components/home/Footer";
import About from "@/components/home/About";

export default function Home() {
  return (
    <div className="min-h-screen">
      <LandingNavbar />
      <main>
        <HeroSection />
        <About />
        <FeaturesSection />
        {/* <TeamSection /> */}
      </main>
      <FooterSection />
    </div>
  );
}
