import React from "react";

const page = () => {
  return <div>register</div>;
};

export default page;
